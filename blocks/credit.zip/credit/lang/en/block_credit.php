<?php

$string['pluginname'] = 'Credit';
$string['title'] = 'Premium courses';
$string['heading'] = 'Premium courses';
$string['course'] = 'Course';
$string['credit'] = 'Credit';
$string['premium'] = 'Premium';
$string['coursecredit'] = 'Enter course credit';
$string['yes'] = 'Yes';
$string['no'] = 'No';

