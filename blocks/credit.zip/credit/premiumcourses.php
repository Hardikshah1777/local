<?php

require_once '../../config.php';
require_once($CFG->libdir . '/tablelib.php');

$courseid = optional_param('courseid',0,PARAM_INT);

$url = new moodle_url('/blocks/credit/premiumcourses.php', ['courseid' => $courseid]);
$context = context_system::instance();

$PAGE->set_title(get_string( 'title', 'block_credit'));
$PAGE->set_heading(get_string( 'heading', 'block_credit'));
$PAGE->set_url($url);
$PAGE->set_context($context);
require_login();

class premiumcourses extends table_sql
{
    public function col_credit(){
        $creditinput = html_writer::tag('input','',['type' => 'text', 'name' => 'coursecredit', 'class' => 'form-control w-50',
                                            'placeholder' => get_string('coursecredit','block_credit')]);
        return $creditinput;
    }

    public function col_premium($row){
        $url = new moodle_url('/blocks/credit/premiumcourses.php');
        $creditinput = '';
        $creditinput .= html_writer::start_tag('form',['action' => $url, 'name' => 'formupdater']);
        $creditinput .= html_writer::tag('input','', ['name'=> 'courseid', 'type' => 'hidden','value' => $row->id]);
            $creditinput .= html_writer::start_tag('select',['name' => 'premium', 'value'=>$row->id ,'class' => 'form-control w-50', 'onchange' => 'this.form.formupdater.click()']);
            if ($row->premium){
                $selected = 'selected';
            }
            $creditinput .= html_writer::tag('option',get_string('yes','block_credit'), [$selected=>$selected, 'value' => 1]);
            $creditinput .= html_writer::tag('option',get_string('no','block_credit'), [$selected=>$selected, 'value' => 0]);
            $creditinput .= html_writer::end_tag('select');
        $creditinput .= html_writer::tag('button','submit',['type'=>'submit', 'name' => 'formupdater', 'class'=>'d-none']);
        $creditinput .= html_writer::end_tag('form');
        return $creditinput;
    }
}
if (!empty($courseid)){
    $course = $DB->get_field('course', 'premium', ['id' => $courseid]);
    if (!empty($course)) {
        $DB->set_field('course','premium',0,['id' => $courseid]);
    } else {
        $DB->set_field('course','premium',1,['id' => $courseid]);
    }
}
$premiumcourses = new premiumcourses('id');
$premiumcourses->set_sql( '*', '{course}', 'id > 1 AND visible = 1');

$col = [
    'id' =>'cid',
    'shortname' => get_string('course','block_credit'),
    'credit' => get_string('credit','block_credit'),
    'premium' => get_string('premium','block_credit'),
];

$premiumcourses->define_headers(array_values($col));
$premiumcourses->define_columns(array_keys($col));
$premiumcourses->sortable(false);
$premiumcourses->collapsible(false);
$premiumcourses->is_downloadable(false);
$premiumcourses->define_baseurl($url);

echo $OUTPUT->header();
$premiumcourses->out(30, false);
echo $OUTPUT->footer();
