<?php

$plugin->version   = 2023120802;
$plugin->requires  = 2021051700;
$plugin->component = 'block_credit';
