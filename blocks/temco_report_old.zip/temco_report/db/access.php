<?php

$capabilities = array(

    'block/block_temco_report:myaddinstance' => array(
        'captype' => 'write',
        'contextlevel' => CONTEXT_SYSTEM,
        'archetypes' => array(
        ),

        'clonepermissionsfrom' => 'moodle/my:manageblocks'
    ),

    'block/block_temco_report:addinstance' => array(
        'riskbitmask' => RISK_SPAM | RISK_XSS,

        'captype' => 'write',
        'contextlevel' => CONTEXT_BLOCK,
        'archetypes' => array(
        ),

        'clonepermissionsfrom' => 'moodle/site:manageblocks'
    ),
);