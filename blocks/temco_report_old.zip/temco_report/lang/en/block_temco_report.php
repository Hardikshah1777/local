<?php

$string['pluginname'] = 'Temco Report';
$string['title'] = 'Reports';
$string['modulecompletion'] = 'Individual modules completion report';
$string['coursecompletion'] = 'Full course completion report';