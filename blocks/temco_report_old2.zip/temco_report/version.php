<?php

defined('MOODLE_INTERNAL') || die();

$plugin->version   = 2025061200;
$plugin->requires  = 2022041200;
$plugin->component = 'block_temco_report';
