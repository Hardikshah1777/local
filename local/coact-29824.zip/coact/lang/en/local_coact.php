<?php

defined('MOODLE_INTERNAL') || die();

$string['pluginname'] = 'Coact Moodle';
$string['usercreatedsuccessfully'] = 'User created successfully';
$string['userupdatedsuccessfully'] = 'User updated successfully';
$string['userexists'] = 'User account already exists';