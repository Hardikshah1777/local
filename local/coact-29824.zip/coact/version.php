<?php

defined('MOODLE_INTERNAL') || die();

$plugin->component = 'local_coact';
$plugin->version   = 2024082700.04;
$plugin->requires  = 2013040500;