<?php

$string['pluginname'] = "Probeit Bookmark";
$string['title'] = "Probeit Bookmark";
$string['heading'] = "Links";
$string['addtitle'] = "Add Probeit Bookmark";
$string['addheading'] = "Add Probeit Bookmark";
$string['tabletitle'] = "Title";
$string['formtitle'] = "Title";
$string['link'] = "Link";
$string['description'] = "Description";
$string['action'] = "Action";
$string['timecreated'] = "Date";
$string['addlink'] = "Add Link";
$string['submit'] = "Submit";
$string['errtitle'] = "Invalid title";
$string['errlink'] = "Invalid link";
$string['insertmsg'] = "Record insert successfully";
$string['updatemsg'] = "Record update successfully";
$string['confirmmsg'] = "Are you sure to delete this record ?";
$string['deletemsg'] = "Record delete successfully";
