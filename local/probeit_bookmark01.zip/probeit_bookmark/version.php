<?php


defined('MOODLE_INTERNAL') || die();

$plugin->version   = 20250121000.01;
$plugin->requires  = 2021051708;
$plugin->component = 'local_probeit_bookmark';
