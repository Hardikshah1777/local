<?php

$plugin->version   = 2023071701.09;
$plugin->requires  = 2016052300;
$plugin->component = 'local_registration';