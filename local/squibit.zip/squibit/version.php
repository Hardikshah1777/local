<?php

/**
 * Version details
 *
 * @package    local_squibit
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

$plugin->version   = 2023081400.15;
$plugin->requires  = 2016101500;
$plugin->component = 'local_squibit';
