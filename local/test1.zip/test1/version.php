<?php

$plugin->version  = 2023112700.07;    // The current module version (Date: YYYYMMDDXX).
$plugin->requires = 2022041200;    // Requires this Moodle version.
$plugin->component = 'local_test1'; // Full name of the plugin (used for diagnostics).