<?php

defined('MOODLE_INTERNAL') || die();

$plugin->version   = 2019052002;        // The current plugin version (Date: YYYYMMDDXX)
$plugin->requires  = 2019051100;        // Requires this Moodle version
$plugin->component = 'local_timetracker';
