<?php

namespace report_temco_completion\table;

use table_dataformat_export_format;
use table_sql;

require_once($CFG->libdir . '/tablelib.php');

class temcoscorm_complete extends table_sql {

    public $validtime;

    protected $timeformat = '%d-%b-%y';

    public function __construct($uniqueid, $customdata = null) {
        global $DB;

        parent::__construct($uniqueid);

        $col = [
            'userfullname' => get_string('fullname', 'report_temco_completion'),
            'cohortname' => get_string('cohortname', 'report_temco_completion'),
            'cohortmanager' => get_string('cohortmanager', 'report_temco_completion'),
            'cshortname' => get_string('scormname', 'report_temco_completion'),
            'coursetimecompleted' => get_string('scormtimecompleted', 'report_temco_completion'),
            'recduration' => get_string('duration', 'report_temco_completion'),
        ];

        $scormid = $DB->get_field('modules', 'id', ['name' => 'scorm']);
        $params['scormid'] = $scormid;
        $field = <<<SQL
CONCAT(u.id, '#', cm.course) as uniqueid, u.id as userid,u.firstname, u.lastname, s.name as cshortname, cmc.timemodified as coursetimecompleted, ch.id as cohortid, ch.name as cohortname, cmc.completionstate, c.recduration
SQL;
        $from = <<<SQL
{course_modules_completion} cmc
JOIN {course_modules} cm ON cm.id = cmc.coursemoduleid
JOIN {user} u ON u.id = cmc.userid
JOIN {scorm} s ON s.id = cm.instance
JOIN {course} c ON c.id = cm.course
LEFT JOIN {cohort_members} chm ON chm.userid = u.id
LEFT JOIN {cohort} ch ON ch.id = chm.cohortid
SQL;
        $where = <<<SQL
 cm.module =:scormid AND u.id > 3 AND u.deleted = 0 AND u.suspended = 0 AND cmc.completionstate = 1 AND (cmc.timemodified > 0 OR cmc.timemodified IS NOT NULL AND cmc.timemodified != 0)
SQL;
        $where .= ' ORDER BY cmc.id ASC';
        $this->set_sql($field, $from, $where, $params);
        $this->define_headers(array_values($col));
        $this->define_columns(array_keys($col));
        $this->sortable(false);
        $this->collapsible(false);

    }

    public function other_cols($column, $row) {
        global $DB;
        if ($column == 'userfullname') {
            $row->$column = $row->firstname.' '.$row->lastname;
        } else if ($column == 'coursetimecompleted') {
            $this->validtime = $row->$column;
            $time = (!empty($row->$column) ? userdate($row->$column, $this->timeformat) : '');
            $row->$column = $time;
        } else if ($column == 'recduration') {
            $recduration = (!empty($row->coursetimecompleted) && !empty($row->recduration)) ? userdate($this->validtime + $row->recduration, $this->timeformat) : '';
            $row->$column = $recduration;
        } else if ($column == 'cohortmanager') {
            if (!empty($row->cohortid)) {
                $managers = $DB->get_records('cohort_members', ['cohortid' => $row->cohortid]);
                $users = [];
                foreach ($managers as $manager) {
                    $user = \core_user::get_user($manager->userid);
                    if (has_capability('report/temco_completion:view', \context_system::instance(), $user)) {
                        $users[] = fullname($user);
                    }
                }
                $row->$column = !empty($users) ? implode(',', $users) : '-';
            }
        }

        return parent::other_cols($column,$row);
    }

    public function render($pagesize, $useinitialsbar = true) {

        $this->out($pagesize, $useinitialsbar);
    }

    public function is_downloading($download = null, $filename='', $sheettitle='') {
        if ($download!==null) {
            $this->sheettitle = $sheettitle;
            $this->is_downloadable(true);
            $this->download = $download;
            $this->filename = clean_filename($filename);
            $this->export_class_instance();
        }
        return $this->download;
    }

    public function export_class_instance($exportclass = null) {
        if (!is_null($exportclass)) {
            $this->started_output = true;
            $this->exportclass = $exportclass;
            $this->exportclass->table = $this;
        } else if (is_null($this->exportclass) && !empty($this->download)) {
            $tempdir = make_temp_directory('temco_completion');
            $filepath = $tempdir . DIRECTORY_SEPARATOR . $this->filename;
            $this->exportclass = new table_dataformat_export_format($this, $this->download);
            if (!$this->exportclass->document_started()) {
                $this->exportclass->start_document($filepath, $this->sheettitle);
            }
        }
        return $this->exportclass;
    }

}