<?php

defined('MOODLE_INTERNAL') || die();

$string['choosereadme'] = 'Boost Child is a child theme of Standard Boost.';
$string['pluginname'] = 'Boost Child';
$string['userenrolsubject'] = 'You are Enrolled in a New Training Course on the Ntiva LMS';
$string['userenroltext'] = 'Hello {$a->firstname} <br /><br />  You have been enrolled in a new course on the Ntiva Learning Management System. The is course is called {$a->course}. You can access this course by clicking the following link: <br /><br />   <a href="{$a->url}" target="_blank">{$a->url}</a> <br /><br /> Please complete this coursework at your earliest convenience. <br /><br /> Sincerely, <br /><br /> The Ntiva Training Team';