<?php

defined('MOODLE_INTERNAL') || die();

$plugin->version   = 2022011001;
$plugin->requires  = 2021051700;
$plugin->component = 'theme_boostchild';
